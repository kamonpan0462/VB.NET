﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MessageBox.Show(" รหัสนักศึกษา " + id.Text + "   ชื่อ  " + STName.Text + "  นามสกุล  " + lastname.Text)
    End Sub


    Private Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Environment.Exit(0)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        id.Text = "634272102"
        STName.Text = "กมลพรรณ"
        lastname.Text = "เขจร"

    End Sub
End Class
