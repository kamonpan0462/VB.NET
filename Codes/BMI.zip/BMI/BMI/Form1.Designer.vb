﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.weight = New System.Windows.Forms.TextBox()
        Me.height = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.bmi = New System.Windows.Forms.Label()
        Me.suggestion = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.suggest = New System.Windows.Forms.RichTextBox()
        Me.result = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(43, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "น้ำหนัก (กิโลกรัม)"
        '
        'weight
        '
        Me.weight.Location = New System.Drawing.Point(46, 52)
        Me.weight.Name = "weight"
        Me.weight.Size = New System.Drawing.Size(103, 20)
        Me.weight.TabIndex = 1
        '
        'height
        '
        Me.height.Location = New System.Drawing.Point(174, 52)
        Me.height.Name = "height"
        Me.height.Size = New System.Drawing.Size(103, 20)
        Me.height.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(171, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "ส่วนสูง (เซนติเมตร)"
        '
        'bmi
        '
        Me.bmi.AutoSize = True
        Me.bmi.Location = New System.Drawing.Point(91, 87)
        Me.bmi.Name = "bmi"
        Me.bmi.Size = New System.Drawing.Size(41, 13)
        Me.bmi.TabIndex = 4
        Me.bmi.Text = "ค่า BMI"
        '
        'suggestion
        '
        Me.suggestion.AutoSize = True
        Me.suggestion.Location = New System.Drawing.Point(33, 145)
        Me.suggestion.Name = "suggestion"
        Me.suggestion.Size = New System.Drawing.Size(53, 13)
        Me.suggestion.TabIndex = 5
        Me.suggestion.Text = "ข้อแนะนำ"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(221, 87)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(77, 49)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "คำนวณ"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'suggest
        '
        Me.suggest.Location = New System.Drawing.Point(27, 176)
        Me.suggest.Name = "suggest"
        Me.suggest.Size = New System.Drawing.Size(271, 73)
        Me.suggest.TabIndex = 7
        Me.suggest.Text = ""
        '
        'result
        '
        Me.result.AutoSize = True
        Me.result.Location = New System.Drawing.Point(83, 114)
        Me.result.Name = "result"
        Me.result.Size = New System.Drawing.Size(66, 13)
        Me.result.TabIndex = 8
        Me.result.Text = "แปลงผลลัพธ์"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(408, 261)
        Me.Controls.Add(Me.result)
        Me.Controls.Add(Me.suggest)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.suggestion)
        Me.Controls.Add(Me.bmi)
        Me.Controls.Add(Me.height)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.weight)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents weight As System.Windows.Forms.TextBox
    Friend WithEvents height As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents bmi As System.Windows.Forms.Label
    Friend WithEvents suggestion As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents suggest As System.Windows.Forms.RichTextBox
    Friend WithEvents result As System.Windows.Forms.Label

End Class
