﻿Option Explicit Off
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        student_id.Text = "634272102"
        student_name.Text = "Kamonpan"
        student_mail.Text = "Kamonpan.kaw@mail.pbru.ac.th"

        Dim birthdatr As Date = #10/24/2001#
        Dim age As Integer

        age = Year(Today()) - Year(birthdatr)
        student_age.Text = age.ToString & "เกิดวัน " & birthdatr.ToString("dddd")
        student_enroll.Text = (16000 * 8).ToString("฿#,###")

    End Sub
End Class
