﻿Public Class Form1
    Dim bprice As New List(Of String) From {35, 35, 45}
    Dim totall As Integer = 0

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim beverage As New List(Of String) From {"เอสเพรสโซ ซิกเนเจอร์", "อเมริกาโน น้ำผึ้ง", "ช็อกโกริโอ"}

        CheckBox1.Text = beverage(0)
        CheckBox2.Text = beverage(1)
        CheckBox3.Text = beverage(2)
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            totall = totall + bprice(0)
        Else
            totall = totall - bprice(0)
        End If
        total.Text = totall
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked Then
            totall = totall + bprice(1)
        Else
            totall = totall - bprice(1)
        End If
        total.Text = totall
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked Then
            totall = totall + bprice(2)
        Else
            totall = totall - bprice(2)
        End If
        total.Text = totall
    End Sub
End Class
